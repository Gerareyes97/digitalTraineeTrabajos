package org.digital.poosupermercado.repositorio;

public enum Direccion {
    ASC,
    DESC
}
