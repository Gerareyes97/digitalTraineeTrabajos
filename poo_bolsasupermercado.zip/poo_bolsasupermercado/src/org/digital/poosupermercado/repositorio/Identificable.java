package org.digital.poosupermercado.repositorio;

public interface Identificable {

    Integer getId();
}

