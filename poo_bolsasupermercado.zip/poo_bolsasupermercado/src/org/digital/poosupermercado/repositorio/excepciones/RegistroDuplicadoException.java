package org.digital.poosupermercado.repositorio.excepciones;

public class RegistroDuplicadoException extends AccesoDatoException{

    public RegistroDuplicadoException(String message) {
        super(message);
    }
}
