package org.digital.poosupermercado.repositorio.excepciones;

public class SinDatosException extends AccesoDatoException{

    public SinDatosException(String message) {
        super(message);
    }
}
