package org.digital.poosupermercado.repositorio.excepciones;

public class AccesoDatoException extends Exception{

    public AccesoDatoException(String message) {
        super(message);
    }
}
