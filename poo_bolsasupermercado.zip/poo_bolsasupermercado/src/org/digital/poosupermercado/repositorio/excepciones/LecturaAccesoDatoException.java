package org.digital.poosupermercado.repositorio.excepciones;

public class LecturaAccesoDatoException extends AccesoDatoException{

    public LecturaAccesoDatoException(String message) {
        super(message);
    }
}
