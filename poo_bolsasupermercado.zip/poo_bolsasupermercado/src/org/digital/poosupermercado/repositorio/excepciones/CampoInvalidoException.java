package org.digital.poosupermercado.repositorio.excepciones;

public class CampoInvalidoException extends AccesoDatoException{

    public CampoInvalidoException(String message) {
        super(message);
    }
}
