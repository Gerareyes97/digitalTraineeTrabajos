package org.digital.poosupermercado.repositorio.excepciones;

public class EscrituraAccesoDatoException extends AccesoDatoException{

    public EscrituraAccesoDatoException(String message) {
        super(message);
    }
}
