package org.digital.poosupermercado.repositorio.excepciones;

public class OperacionNoEncontradaException extends AccesoDatoException{

    public OperacionNoEncontradaException(String message) {
        super(message);
    }
}
