package org.digital.poosupermercado.repositorio;

public interface IContableRepositorio {
    int total();
}
