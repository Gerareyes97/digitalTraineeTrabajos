package org.digital.poosupermercado.modelo.persona;

public interface IPersona {

    String mostrarInfo();
}
