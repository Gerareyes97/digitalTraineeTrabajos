package org.digital.poosupermercado.modelo.persona;

public interface IProducto {
    double calcularImpuesto();
    String descripcion();
}
